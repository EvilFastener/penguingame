﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.VectorGraphics")]
[assembly: InternalsVisibleTo("Unity.VectorGraphics.Editor")]