﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.VectorGraphics.Tests")]
[assembly: InternalsVisibleTo("Unity.VectorGraphics.Editor")]
[assembly: InternalsVisibleTo("Unity.VectorGraphics.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.InternalAPIEngineBridge.003")]
[assembly: InternalsVisibleTo("Unity.InternalAPIEditorBridge.003")]
